<?php
use Illuminate\Support\Facades\Route;

Route::prefix('user')->group(function(){  
    require __DIR__ . '/accounts.php';
    require __DIR__ . '/profile.php';
    require __DIR__ . '/security.php';
    require __DIR__ . '/workspaces.php';
    
    Route::middleware(['client.context'])->group(function(){
        require __DIR__ . '/members.php';
        require __DIR__ . '/invitations.php';
    });
});